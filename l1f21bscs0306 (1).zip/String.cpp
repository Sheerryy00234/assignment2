#include <iostream>
#include "String.h"
using namespace std;

String::String()
{
	bb = nullptr;
}

String::String(const String& str)
{
	int s = 0;

	while (1)
	{
		if (str.bb[s] == '\0')
			break;

		s++;
	}

	bb = new char[s + 1];

	for (int i = 0; i < s; i++)
	{
		bb[i] = str.bb[i];
	}

	bb[s] = '\0';
}

String::String(const String& str, int pos, int len)
{
	bb = new char[len + 1];

	int j = pos;
	for (int i = 0; i < len; i++)
	{
		bb[i] = str.bb[j];
		j++;
	}
	bb[len] = '\0';
}
String::String(const char* s)
{
	int length = 0;
	for (int i = 0; s[i] != '\0'; i++)
	{
		length++;
	}

	bb = new char[length + 1];

	for (int i = 0; i < length; i++)
	{
		bb[i] = s[i];
	}
	bb[length] = '\0';
}
String::String(const char* s, int n)
{
	bb = new char[n];

	for (int i = 0; i < n; i++)
	{
		bb[i] = s[i];
	}
	bb[n] = '\0';
}

String::String(int n, char c)
{
	bb = new char[n];

	for (int i = 0; i < n; i++)
	{
		bb[i] = c;
	}
	bb[n] = '\0';
}

int String::length()
{
	int len = 0;
	for (int i = 0; bb[i] != '\0'; i++)
	{
		len++;
	}
	return len;
}

char String::at(int i)
{
	return bb[i];
}

String String::substr(int pos, int len) const
{
	String temp;

	temp.bb = new char[len];

	int j = pos;
	for (int i = 0; i < len; i++)
	{
		temp.bb[i] = bb[j];
		j++;
	}
	temp.bb[len] = '\0';

	return temp;
}